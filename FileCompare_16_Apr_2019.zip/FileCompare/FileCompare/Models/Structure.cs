
public class Structure { 	
	public string CUSIP { get; set; }	
	public string TICKER { get; set; }	
	public string SEDOL { get; set; }	
	public string ISIN { get; set; }	
	public string DESCRIPTION { get; set; }	
	public string CUR { get; set; }	
	public string ISO { get; set; }	
	public int SHARES { get; set; }	
	public string ORIGINAL_FACE { get; set; }	
	public int INTEREST { get; set; }	
	public double LOCAL_PRICE { get; set; }	
	public double LOCAL_MV { get; set; }	
	public int FOREX { get; set; }	
	public double BASE_PRICE { get; set; }	
	public double BASE_MV { get; set; }	
	public double WEIGHT { get; set; }	
	public string CIL { get; set; }	
	public int EST_DIVIDEND { get; set; }	
	public int LOT { get; set; }	
	public string NEW { get; set; }	
	public int SHARE_CHANGE { get; set; }	
	public int INT_FACTOR { get; set; }	
	public int PAR_ADJUSTMENT_FACTOR { get; set; }
}
