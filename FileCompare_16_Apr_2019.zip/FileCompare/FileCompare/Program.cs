﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace FileCompare
{
    class Program
    {
        static void Main(string[] args)
        {
            string filepath1 = @"D:\Compare\PLF1.csv";
            DataTable table1 = ConvertCSVtoDataTable(filepath1);
            string filepath2 = @"D:\Compare\PLF2.csv";
            DataTable table2 = ConvertCSVtoDataTable(filepath2);

            List<Structure> list1 = GetList(table1);
            List<Structure> list2 = GetList(table2);

            //DataTable dt = compareDataTables(table1,table2);
            DataTable dt1 = compareTables(table1,table2,"PCF_PLF");
            //DataTable dt2 = compareTables(table2, table1, "PLF_PCF");
            //dt1.Merge(dt2);

            dt1.ToCSV(@"D:\structures\compare_data.csv");

        }

        public static DataTable compareDataTables(DataTable First, DataTable Second)
        {
            First.TableName = "FirstTable";
            Second.TableName = "SecondTable";

            //Create Empty Table
            DataTable table = new DataTable("Difference");
            DataTable table1 = new DataTable();
            try
            {
                //Must use a Dataset to make use of a DataRelation object
                using (DataSet ds4 = new DataSet())
                {
                    //Add tables
                    ds4.Tables.AddRange(new DataTable[] { First.Copy(), Second.Copy() });

                    //Get Columns for DataRelation
                    DataColumn[] firstcolumns = new DataColumn[ds4.Tables[0].Columns.Count];
                    for (int i = 0; i < firstcolumns.Length; i++)
                    {
                        firstcolumns[i] = ds4.Tables[0].Columns[i];
                    }
                    DataColumn[] secondcolumns = new DataColumn[ds4.Tables[1].Columns.Count];
                    for (int i = 0; i < secondcolumns.Length; i++)
                    {
                        secondcolumns[i] = ds4.Tables[1].Columns[i];
                    }
                    //Create DataRelation
                    DataRelation r = new DataRelation(string.Empty, firstcolumns, secondcolumns, false);
                    ds4.Relations.Add(r);
                    //Create columns for return table
                    for (int i = 0; i < First.Columns.Count; i++)
                    {
                        table.Columns.Add(First.Columns[i].ColumnName, First.Columns[i].DataType);
                    }
                    //If First Row not in Second, Add to return table.
                    table.BeginLoadData();
                    foreach (DataRow parentrow in ds4.Tables[0].Rows)
                    {
                        DataRow[] childrows = parentrow.GetChildRows(r);

                        if (childrows == null || childrows.Length == 0)
                            table.LoadDataRow(parentrow.ItemArray, true);
                        table1.LoadDataRow(childrows, false);

                    }
                    table.EndLoadData();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return table;
        }


        public static DataTable compareTables(DataTable table1,DataTable table2,string filter)
        {
            if (!table1.Columns.Contains("Compare Result"))
            {
                DataColumn resutColumn1 = table1.Columns.Add("Compare Result");
                resutColumn1.SetOrdinal(0);// to put the column in position 0;
            }

            if (!table2.Columns.Contains("Compare Result"))
            {
                DataColumn resutColumn2 = table2.Columns.Add("Compare Result");
                resutColumn2.SetOrdinal(0);// to put the column in position 0;
            }
                                  

            DataTable ResultDataTable = table1.Clone();

            DataTable PrimaryTable = null;
            DataTable SecondaryTable = null;

            PrimaryTable = table1;
            SecondaryTable = table2;

          
            foreach (DataRow row in PrimaryTable.Rows)
            {

                // DataTable dt = rowMasterItem.Table.Clone();
                var matchedRow= from o in SecondaryTable.AsEnumerable()
                                where o.Field<string>("CUSIP") == row["CUSIP"].ToString() &&
                                o.Field<string>("FUND CODE") == row["FUND CODE"].ToString()
                                select o;
                
                if (matchedRow.Count()!=0)
                {
                    if (row.ItemArray.SequenceEqual(matchedRow.FirstOrDefault().ItemArray))
                    {
                        row["Compare Result"] = (filter=="PCF_PLF")?"PCF File":"PLF File";
                        ResultDataTable.ImportRow(row);

                        var recordInSecond = SecondaryTable.AsEnumerable().FirstOrDefault(row1 => row1["CUSIP"].ToString() == row["CUSIP"].ToString() && row1["FUND CODE"].ToString() == row["FUND CODE"].ToString());
                        recordInSecond["Compare Result"] = (filter == "PCF_PLF") ? "PCF File" : "PLF File"; 
                        ResultDataTable.ImportRow(recordInSecond);


                        row["Compare Result"] = "Matched";
                        ResultDataTable.ImportRow(row);
                    }
                    else
                    {
                        row["Compare Result"] = "PCF File";
                        ResultDataTable.ImportRow(row);

                        var recordInSecond = matchedRow.FirstOrDefault();
                        recordInSecond["Compare Result"] = (filter == "PCF_PLF") ? "PCF File" : "PLF File";
                        ResultDataTable.ImportRow(recordInSecond);


                        row["Compare Result"] = "Not Matched";
                        ResultDataTable.ImportRow(row);

                    }
                    
                }
                else
                {
                    row["Compare Result"] = (filter == "PCF_PLF") ? "PCF File" : "PLF File";
                    ResultDataTable.ImportRow(row);

                    /*DataTable table = new DataTable();
                    DataRow emptyrow = table.NewRow();
                    table.Rows.Add(row);*/
                    if (filter == "PCF_PLF") {
                        row["Compare Result"] = "Record Doesnt exist in PLF File";
                    }
                    else {
                        row["Compare Result"] = "Record Doesnt exist in PCF File";
                    }
                   
                    ResultDataTable.ImportRow(row);
                }
                
            }

            DataTable dtOnlyPLF = PrimaryTable.AsEnumerable().Except(
            SecondaryTable.AsEnumerable(), DataRowComparer.Default).
            CopyToDataTable();

            DataTable dtUncommon = SecondaryTable.AsEnumerable().Except(PrimaryTable.AsEnumerable()).CopyToDataTable();


            var Unmatched = (from t in SecondaryTable.AsEnumerable()
                             where !PrimaryTable.AsEnumerable().Any(f => f.Field<string>("CUSIP") == t.Field<string>("CUSIP") && f.Field<string>("FUND CODE") == t.Field<string>("FUND CODE"))
                             select t);
             foreach (DataRow r in Unmatched.AsEnumerable())
             {
                 r["Compare Result"] = "PLF File";
                 ResultDataTable.ImportRow(r);

                 r["Compare Result"] = "Record Doesnt exist in PCF File";
                 ResultDataTable.ImportRow(r);
             }
             
            return ResultDataTable;
        }
        
        /* static void Main(string[] args)
         {
             //---use below two lines to generate a poco class from the csv file.
             //var cSharpClass = CsvToClass.CSharpClassCodeFromCsvFile(@"D:\structures\structure1.csv", ",", "[DelimitedRecord(\",\")]", "[FieldOptional()]");
             //File.WriteAllText(@"D:\structures\OutputFile.cs", cSharpClass);
             //-----------------------------------------------------------------

             var sourceFile = File.ReadAllLines(@"D:\structures\structure1.csv");
             var destinationFile = File.ReadAllLines(@"D:\structures\structure2.csv");
             string filepath1 = @"D:\structures\structure1.csv";
             DataTable table1 = ConvertCSVtoDataTable(filepath1);
             string filepath2 = @"D:\structures\structure2.csv";            
             DataTable table2 = ConvertCSVtoDataTable(filepath2);

             //Transforming Datatable to list
             List<Structure> list1 = GetList(table1);
             List<Structure> list2 = GetList(table2);
             //----one way of comparing the list objects. this will give matching records with list2
             var q = list1.Where(item => list2.Select(item2 => item2).Contains(item));
             foreach (var i in q)
             {
                 Console.WriteLine(i); 
             }

             var list1_in_list2 = from first in list1
                                        join second in list2
                                        on first.CUSIP equals second.CUSIP
                                        select first;

             //use below line if u want to trnasform the resul to datatable and then to file.
             //---------------------------------------------------------------------
             var list1_in_list2_another = from first in list1
                                  join second in list2
                                  on first.CUSIP equals second.CUSIP
                                  select first;
             DataTable result = ToDataTable<Structure>(list1_in_list2_another);
             result.ToCSV(@"D:\structures\result.csv");
             //---------------------------------------------------------------------


             //---Another way of comparing the objects.
             var filtered = list1.Except(list2); //this will have all the objects which are not included in list2


              //------ this will give u the common rows available in both files
              /*DataTable dtMerged =(from a in table1.AsEnumerable()
                               join b in table2.AsEnumerable()
                               on a["CUSIP"].ToString() equals b["CUSIP"].ToString() into g
                               where g.Count() > 0
                               select a).CopyToDataTable();*
        // dtMerged.ToCSV(@"D:\structures\test.csv");

     }*/


        public static List<Structure> GetList(DataTable table)
        {            
            List<Structure> list = new List<Structure>();
            list = CommonMethod.ConvertToList<Structure>(table);
            return list;
        }


        public static DataTable ToDataTable<T>(IEnumerable<T> l_oItems)
        {
            DataTable oReturn = new DataTable(typeof(T).Name);
            object[] a_oValues;
            int i;

            //#### Collect the a_oProperties for the passed T
            PropertyInfo[] a_oProperties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            //#### Traverse each oProperty, .Add'ing each .Name/.BaseType into our oReturn value
            //####     NOTE: The call to .BaseType is required as DataTables/DataSets do not support nullable types, so it's non-nullable counterpart Type is required in the .Column definition
            foreach (PropertyInfo oProperty in a_oProperties)
            {
                oReturn.Columns.Add(oProperty.Name, BaseType(oProperty.PropertyType));
            }

            //#### Traverse the l_oItems
            foreach (T oItem in l_oItems)
            {
                //#### Collect the a_oValues for this loop
                a_oValues = new object[a_oProperties.Length];

                //#### Traverse the a_oProperties, populating each a_oValues as we go
                for (i = 0; i < a_oProperties.Length; i++)
                {
                    a_oValues[i] = a_oProperties[i].GetValue(oItem, null);
                }

                //#### .Add the .Row that represents the current a_oValues into our oReturn value
                oReturn.Rows.Add(a_oValues);
            }

            //#### Return the above determined oReturn value to the caller
            return oReturn;
        }

        public static Type BaseType(Type oType)
        {
            //#### If the passed oType is valid, .IsValueType and is logicially nullable, .Get(its)UnderlyingType
            if (oType != null && oType.IsValueType &&
                oType.IsGenericType && oType.GetGenericTypeDefinition() == typeof(Nullable<>)
            )
            {
                return Nullable.GetUnderlyingType(oType);
            }
            //#### Else the passed oType was null or was not logicially nullable, so simply return the passed oType
            else
            {
                return oType;
            }
        }

        public static DataTable ConvertCSVtoDataTable(string strFilePath)
        {
            StreamReader sr = new StreamReader(strFilePath);
            string[] headers = sr.ReadLine().Split(',');
            DataTable dt = new DataTable();
            foreach (string header in headers)
            {
                dt.Columns.Add(header);
            }
            while (!sr.EndOfStream)
            {
                string[] rows = Regex.Split(sr.ReadLine(), ",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
                DataRow dr = dt.NewRow();
                for (int i = 0; i < headers.Length; i++)
                {
                    dr[i] = rows[i];
                }
                dt.Rows.Add(dr);
            }
            return dt;
        }
    }
}
