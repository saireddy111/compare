﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace FileCompare
{
    class Program
    {
        static void Main(string[] args)
        {
            var sourceFile = File.ReadAllLines(@"D:\structures\structure1.csv");
            var destinationFile = File.ReadAllLines(@"D:\structures\structure2.csv");
            string filepath1 = @"D:\structures\structure1.csv";
            DataTable table1 = ConvertCSVtoDataTable(filepath1);
            string filepath2 = @"D:\structures\structure2.csv";            
            DataTable table2 = ConvertCSVtoDataTable(filepath2);

            //compare line by line
            /*var compareFile = (from ln in sourceFile
                              from ln1 in destinationFile
                              where ln == ln1
                              select ln);*/

            /*var res= from DataRow myRow in table1.Rows
            //where (int)myRow["RowNo"] == 1
            select myRow;
            var res1 = from p in table1.AsEnumerable()
                       select p;
            DataView view = res1.AsDataView();*/


            //------ this will give u the common rows available in both files
            DataTable dtMerged =(from a in table1.AsEnumerable()
                              join b in table2.AsEnumerable()
                              on a["CUSIP"].ToString() equals b["CUSIP"].ToString() into g
                              where g.Count() > 0
                              select a).CopyToDataTable();
            dtMerged.ToCSV(@"D:\structures\test.csv");




        }

        public static DataTable ConvertCSVtoDataTable(string strFilePath)
        {
            StreamReader sr = new StreamReader(strFilePath);
            string[] headers = sr.ReadLine().Split(',');
            DataTable dt = new DataTable();
            foreach (string header in headers)
            {
                dt.Columns.Add(header);
            }
            while (!sr.EndOfStream)
            {
                string[] rows = Regex.Split(sr.ReadLine(), ",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
                DataRow dr = dt.NewRow();
                for (int i = 0; i < headers.Length; i++)
                {
                    dr[i] = rows[i];
                }
                dt.Rows.Add(dr);
            }
            return dt;
        }
    }
}
