﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace FileCompare
{
    class Program
    {
        static void Main(string[] args)
        {
            //---use below two lines to generate a poco class from the csv file.
            //var cSharpClass = CsvToClass.CSharpClassCodeFromCsvFile(@"D:\structures\structure1.csv", ",", "[DelimitedRecord(\",\")]", "[FieldOptional()]");
            //File.WriteAllText(@"D:\structures\OutputFile.cs", cSharpClass);
            //-----------------------------------------------------------------
            
            var sourceFile = File.ReadAllLines(@"D:\structures\structure1.csv");
            var destinationFile = File.ReadAllLines(@"D:\structures\structure2.csv");
            string filepath1 = @"D:\structures\structure1.csv";
            DataTable table1 = ConvertCSVtoDataTable(filepath1);
            string filepath2 = @"D:\structures\structure2.csv";            
            DataTable table2 = ConvertCSVtoDataTable(filepath2);

            //Transforming Datatable to list
            List<Structure> list1 = GetList(table1);
            List<Structure> list2 = GetList(table2);
            //----one way of comparing the list objects. this will give matching records with list2
            var q = list1.Where(item => list2.Select(item2 => item2).Contains(item));
            foreach (var i in q)
            {
                Console.WriteLine(i); 
            }
                       
            //---Another way of comparing the objects.
            var filtered = list1.Except(list2); //this will have all the objects which are not included in list2
                       
             
             //------ this will give u the common rows available in both files
             /*DataTable dtMerged =(from a in table1.AsEnumerable()
                              join b in table2.AsEnumerable()
                              on a["CUSIP"].ToString() equals b["CUSIP"].ToString() into g
                              where g.Count() > 0
                              select a).CopyToDataTable();*/
           // dtMerged.ToCSV(@"D:\structures\test.csv");
                                 
        }
        public static List<Structure> GetList(DataTable table)
        {            
            List<Structure> list = new List<Structure>();
            list = CommonMethod.ConvertToList<Structure>(table);
            return list;
        }


        public static DataTable ConvertCSVtoDataTable(string strFilePath)
        {
            StreamReader sr = new StreamReader(strFilePath);
            string[] headers = sr.ReadLine().Split(',');
            DataTable dt = new DataTable();
            foreach (string header in headers)
            {
                dt.Columns.Add(header);
            }
            while (!sr.EndOfStream)
            {
                string[] rows = Regex.Split(sr.ReadLine(), ",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
                DataRow dr = dt.NewRow();
                for (int i = 0; i < headers.Length; i++)
                {
                    dr[i] = rows[i];
                }
                dt.Rows.Add(dr);
            }
            return dt;
        }
    }
}
