﻿using CsvComparator.Models;
using CsvHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace CsvComparator
{
    public static class TestFileReader
    {

        public static List<dynamic> ReadSecondaryFile(string filePath)
        {
            //filePath = @"D:\testPLF.csv";
            filePath = @"D:\PLFwithmultipleaccounts.csv";


            Console.WriteLine("\n-------------------Reading TestPLF File-------------------\n");
            using (var reader = new StreamReader(filePath))
            using (var csv = new CsvReader(reader))
            {
                var ignoreStrings = new string[] {
                    "Manager Workbench - PMG_MWB_1 (6A75)"
                    ,"ETFs \\ Positions"
                };
                var records = new List<dynamic>();
                csv.Configuration.IgnoreBlankLines = true;
                csv.Configuration.MissingFieldFound = null;

                for (var i = 0; i < 2; i++)
                {
                    csv.Read();
                }
                while (csv.Read())
                {
                    var startValue = csv.GetField(0);
                    if (ignoreStrings.Contains(startValue))
                    {
                        continue;
                    }
                    else if (startValue.Contains("Security"))
                    {
                        csv.ReadHeader();
                    }
                    else
                    {
                        var record = csv.GetRecord<PrimaryFile>();
                        record.FUNDCODE = csv.GetField(6);
                        record.ISIN = csv.GetField(8);
                        record.CUSIP = csv.GetField(9);
                        record.SEDOL = csv.GetField(11);
                        record.CURRENCYCODE = csv.GetField(17);
                        record.CIL= csv.GetField(18);
                        record.TRADECOUNTRY = csv.GetField(20);

                        if (!string.IsNullOrEmpty(record.FUNDCODE))
                            records.Add(record);
                    }

                }
                foreach (var record in records)
                {
                    Console.WriteLine(record);
                }
                return records;

            }
        }
    }
}
