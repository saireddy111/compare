﻿namespace CsvComparator
{
    class Program
    {
        static readonly string primaryFile = @"C:\Users\PrimaryFile.csv";
        static readonly string secondaryFile = @"C:\Users\SecondaryFile.csv";
        static readonly string outputFile = @"D:\Output.csv";

        static void Main(string[] args)
        {
            FileWriter.WriteOutputFile(TestFileReader.ReadSecondaryFile(""), outputFile);
        }
    }
}
