﻿using CsvHelper.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CsvComparator.Models
{
    public class SecondaryFile
    {
        public string FUNDCODE { get; set; }
        private string _CUSIP;
        public string CUSIP
        {
            get
            {
                return this._CUSIP;
            }
            set
            {
                if (!string.IsNullOrEmpty(value))
                    this._CUSIP = value.Replace("'", "");
            }
        }

        private string _TICKER;
        public string TICKER
        {
            get
            {
                return this._TICKER;
            }
            set
            {
                if (!string.IsNullOrEmpty(value))
                    this._TICKER = value.Replace("'", "");
            }
        }

        private string _SEDOL;
        public string SEDOL
        {
            get
            {
                return this._SEDOL;
            }
            set
            {
                if (!string.IsNullOrEmpty(value))
                    this._SEDOL = value.Replace("'", "");
            }
        }
        public string ISIN { get; set; }
        public string DESCRIPTION { get; set; }
        public string CUR { get; set; }
        public string ISO { get; set; }
        public int? SHARES { get; set; }
        public string ORIGINAL_FACE { get; set; }
        public int? INTEREST { get; set; }
        public double? LOCAL_PRICE { get; set; }
        public double? LOCAL_MV { get; set; }
        public double? FOREX { get; set; }
        public double? BASE_PRICE { get; set; }
        public double? BASE_MV { get; set; }
        public double? WEIGHT { get; set; }
        public string CIL { get; set; }
        public double? EST_DIVIDEND { get; set; }
        public int? LOT { get; set; }
        public string NEW { get; set; }
        public int? SHARE_CHANGE { get; set; }
        public int? INT_FACTOR { get; set; }
        public int? PAR_ADJUSTMENT_FACTOR { get; set; }
        public override string ToString()
        {
            var text = string.Join
            (
                ",",
                typeof(SecondaryFile)
                    .GetProperties(BindingFlags.Instance | BindingFlags.Public)
                    .Select
                    (
                        prop => prop.GetValue(this)?.ToString()
                    )
            );
            return text;
        }

        public string TRADECOUNTRY { get; set; }
    }

    //public class SecondaryFileMap : ClassMap<SecondaryFile>
    //{
    //    public SecondaryFileMap()
    //    {
    //        Map(m => m.CUSIP).Name("CUSIP");
    //        Map(m => m.TICKER).Name("TICKER");
    //        Map(m => m.SEDOL).Name("SEDOL");
    //        Map(m => m.ISIN).Name("ISIN");
    //        Map(m => m.DESCRIPTION).Name("DESCRIPTION");
    //        Map(m => m.CUR).Name("CUR");
    //        Map(m => m.ISO).Name("ISO");
    //        Map(m => m.SHARES).Name("SHARES");
    //        Map(m => m.ORIGINAL_FACE).Name("ORIGINAL_FACE");
    //        Map(m => m.INTEREST).Name("INTEREST");
    //        Map(m => m.LOCAL_PRICE).Name("LOCAL_PRICE");
    //        Map(m => m.LOCAL_MV).Name("LOCAL_MV");
    //        Map(m => m.FOREX).Name("FOREX");
    //        Map(m => m.BASE_PRICE).Name("BASE_PRICE");
    //        Map(m => m.BASE_MV).Name("BASE_MV");
    //        Map(m => m.WEIGHT).Name("WEIGHT");
    //        Map(m => m.CIL).Name("CIL");
    //        Map(m => m.EST_DIVIDEND).Name("EST_DIVIDEND");
    //        Map(m => m.LOT).Name("LOT");
    //        Map(m => m.NEW).Name("NEW");
    //        Map(m => m.SHARE_CHANGE).Name("SHARE_CHANGE");
    //        Map(m => m.INT_FACTOR).Name("INT_FACTOR");
    //        Map(m => m.PAR_ADJUSTMENT_FACTOR).Name("PAR_ADJUSTMENT_FACTOR");
    //        Map(m => m.TRADECOUNTRY).Name("TRADE_COUNTRY");
    //    }
    //}

}
