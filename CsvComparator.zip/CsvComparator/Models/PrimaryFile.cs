﻿using CsvHelper.Configuration;
using System.Linq;
using System.Reflection;

namespace CsvComparator.Models
{
    public class PrimaryFile
    {
        public string FUNDCODE { get; set; }
        public string ISIN { get; set; }
        public string CUSIP { get; set; }
        public string SEDOL { get; set; }
        public int? BASKETSHARES { get; set; }
        public string CURRENCYCODE { get; set; }
        public string CIL { get; set; }
        public string TRADECOUNTRY { get; set; }

        public override string ToString()
        {
            var text = string.Join
            (
                ",",
                typeof(PrimaryFile)
                    .GetProperties(BindingFlags.Instance | BindingFlags.Public)
                    .Select
                    (
                        prop => prop.GetValue(this) //.ToString()
                    )
            );
            return text;
        }
    }

    public class PrimaryFileMap : ClassMap<PrimaryFile>
    {
        public PrimaryFileMap()
        {
            Map(m => m.FUNDCODE).Name("FUND CODE");
            Map(m => m.ISIN).Name("ISIN");
            Map(m => m.CUSIP).Name("CUSIP");
            Map(m => m.SEDOL).Name("SEDOL");
            Map(m => m.BASKETSHARES).Name("BASKET SHARES");
            Map(m => m.CURRENCYCODE).Name("CURRENCY CODE");
            Map(m => m.CIL).Name("CIL");
            Map(m => m.TRADECOUNTRY).Name("TRADE COUNTRY");
        }
    }
}
