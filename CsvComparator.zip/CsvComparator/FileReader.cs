﻿using CsvComparator.Models;
using CsvHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsvComparator
{
    public static class FileReader
    {

        public static List<PrimaryFile> ReadPrimaryFile(string filePath)
        {
            Console.WriteLine("\n-------------------Reading Primary File-------------------\n");
            using (var reader = new StreamReader(filePath))
            using (var csv = new CsvReader(reader))
            {
                csv.Configuration.IgnoreBlankLines = true;
                csv.Configuration.RegisterClassMap<PrimaryFileMap>();

                var records = new List<PrimaryFile>();
                var isHeader = true;
                while (csv.Read())
                {
                    if (isHeader)
                    {
                        csv.ReadHeader();
                        isHeader = false;
                        continue;
                    }

                    if (string.IsNullOrEmpty(csv.GetField(0)))
                    {
                        isHeader = true;
                        continue;
                    }

                    switch (csv.Context.HeaderRecord[0])
                    {
                        case "FUND CODE":
                            records.Add(csv.GetRecord<PrimaryFile>());
                            break;
                        default:
                            throw new InvalidOperationException("Unknown record type.");
                    }
                }

                foreach (var record in records)
                {
                    Console.WriteLine(record);
                }

                return records;
            }
        }

        public static List<SecondaryFile> ReadSecondaryFile(string filePath)
        {
            Console.WriteLine("\n-------------------Reading Secondary File-------------------\n");
            using (var reader = new StreamReader(filePath))
            using (var csv = new CsvReader(reader))
            {
                var ignoreStrings = new string[] {
                    "CREATION_UNIT_SIZE"
                    ,"SETTLEMENT_CYCLE"
                    ,"NAV"
                    ,"NAV_PER_CREATION_UNIT"
                    ,"NAV_LESS_UNDISTRIBUTED_NET_INCOME"
                    ,"ETF_SHARES_OUTSTANDING"
                    ,"TOTAL_NET_ASSETS"
                };
                var records = new List<SecondaryFile>();
                csv.Configuration.IgnoreBlankLines = true;
                csv.Configuration.MissingFieldFound = null;
                string fundName = null;

                while (csv.Read())
                {
                    var startValue = csv.GetField(0);
                    if (ignoreStrings.Contains(startValue))
                    {
                        continue;
                    }
                    else if (startValue.Contains("TRADE_DATE"))
                    {
                        fundName = csv.GetField(2);
                    }
                    else if (startValue.Contains("CUSIP"))
                    {
                        csv.ReadHeader();
                    }
                    else
                    {
                        var record = csv.GetRecord<SecondaryFile>();
                        record.FUNDCODE = fundName;
                        records.Add(record);
                    }

                }
                foreach (var record in records)
                {
                    Console.WriteLine(record);
                }
                return records;

            }
        }
    }
}
